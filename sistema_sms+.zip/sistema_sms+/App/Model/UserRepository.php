<?php



namespace App\Model;



use Nextc\Model\Conteiner;

use Exception;

use DateTime;

use PDOException;



class UserRepository extends Conteiner

{

}

