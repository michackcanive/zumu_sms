<?php

namespace App\Model;

use Exception;
use Nextc\Model\Conteiner;

class UsersRepository extends Conteiner
{
    public function findByUserAll($tipo_de_conta)
    {
    }
}
