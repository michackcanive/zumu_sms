<?php

define(
    "API_URL",
    'https://api.olasms.com/api/'
);
define(
    "API_URL_ONLINE",
    'https://api.olasms.com/api/'
);
define(
    "API_URL_LOGO",
    'https://api.olasms.com/'
);
define(
    "EMAIL_EMPRESA",
    'geral@seuemailempresa.com'
);

define(
    "USERNAME",
    'smtp.seu.com'
);
define(
    "SENHA_EMAIL",
    'suasenha'
);
