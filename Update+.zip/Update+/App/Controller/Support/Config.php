
<?php

define("FACEBOOK",[
    'clientId'          => '1448737292211123',
    'clientSecret'      => '{f18c3335210fd57fbef9d847545752ed}',
    'redirectUri'       => 'https://example.com/callback-url',
    'graphApiVersion'   => 'v2.10',
]);


